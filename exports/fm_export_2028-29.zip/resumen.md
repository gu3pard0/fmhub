# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 7.º de 24 con 11 puntos (3V 2E 1D, 12-8).
- **Temporada en curso** (datos a 2028-09-02).
- **Oficiales:** 8 partidos, 3V 2E 3D, goles 15-14.
- Bristol Street Motors Trophy: 1 partidos, 0V 0E 1D.
- Carabao Cup: 1 partidos, 0V 0E 1D.

- **Goleadores:** Alfie Matthews 3, Tyler Cordner 3, Joe Knight 2.
- **Asistencias:** Kwadwo Baah 4, Jack Smith 2, Keanu Chalaye 1.
- **Mejor nota (mín. 10 partidos):** —.
- **Más partidos:** Keanu Chalaye 9, Alfie Matthews 8, Cameron Harper 8.
- **Mayor victoria:** 3-0 a Wycombe Wanderers (2028-08-26). **Peor derrota:** 1-3 contra Wycombe Wanderers (2028-08-29).
- **Rachas:** 1 victorias seguidas, 4 sin perder; 1 porterías a cero.
- **Público en casa:** media de 4.618 espectadores.
- **Traspasos:** 3 fichajes (0 €) y 4 salidas (0 €).
- **Economía (suma mensual):** ingresos 2.146.353 €. gastos 1.660.952 €. neto 485.402 €.

**Hitos:**
- 7.º de 24 en Sky Bet League One con 11 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos
- Bristol Street Motors Trophy: 1 partidos; el último, no ganado 1-3 contra Wycombe Wanderers el 2028-08-29
- Carabao Cup: 1 partidos; el último, no ganado 2-3 contra Huddersfield Town el 2028-08-01

Plantilla: 40 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
