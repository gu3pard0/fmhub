# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 15.º de 24 con 5 puntos (1V 2E 1D, 7-7).
- **Temporada en curso** (datos a 2028-08-19).
- **Oficiales:** 5 partidos, 1V 2E 2D, goles 9-10.
- Carabao Cup: 1 partidos, 0V 0E 1D.

- **Goleadores:** Alfie Matthews 2, Jesús Belza 2, Joe Knight 2.
- **Asistencias:** Jack Smith 2, Keanu Chalaye 1, Joe Knight 1.
- **Mejor nota (mín. 10 partidos):** —.
- **Más partidos:** Ryan Evans 7, Keanu Chalaye 6, Alfie Matthews 5.
- **Mayor victoria:** 2-1 a Peterborough United (2028-08-12). **Peor derrota:** 2-3 contra Huddersfield Town (2028-08-01).
- **Rachas:** 1 victorias seguidas, 3 sin perder; 0 porterías a cero.
- **Público en casa:** media de 4.510 espectadores.
- **Traspasos:** 3 fichajes (0 €) y 4 salidas (0 €).
- **Economía (suma mensual):** ingresos 1.839.972 €. gastos 1.018.145 €. neto 821.827 €.

**Hitos:**
- 15.º de 24 en Sky Bet League One con 5 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos
- Carabao Cup: 1 partidos; el último, no ganado 2-3 contra Huddersfield Town el 2028-08-01

Plantilla: 40 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
