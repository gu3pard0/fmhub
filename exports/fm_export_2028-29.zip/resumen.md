# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 1.º de 24 con 38 puntos (12V 2E 1D, 39-19).
- **Temporada en curso** (datos a 2028-10-28).
- **Oficiales:** 19 partidos, 13V 3E 3D, goles 45-26.
- Bristol Street Motors Trophy: 2 partidos, 0V 1E 1D.
- Carabao Cup: 1 partidos, 0V 0E 1D.
- Copa FA inglesa: 1 partidos, 1V 0E 0D.

- **Goleadores:** Alfie Matthews 7, Kwadwo Baah 7, Basil Tuma 6.
- **Asistencias:** Kwadwo Baah 7, Jack Smith 6, Jesús Belza 4.
- **Mejor nota (mín. 10 partidos):** Kwadwo Baah 7.27, Maxwell Statham 7.14, Jack Smith 7.11.
- **Más partidos:** Alfie Matthews 19, Cameron Harper 18, Evan Anderson 18.
- **Mayor victoria:** 4-0 a Forest Green Rovers (2028-10-21). **Peor derrota:** 1-3 contra Wycombe Wanderers (2028-08-29).
- **Rachas:** 6 victorias seguidas, 12 sin perder; 6 porterías a cero.
- **Público en casa:** media de 4.580 espectadores.
- **Traspasos:** 4 fichajes (0 €) y 4 salidas (194.586 €).
- **Economía (suma mensual):** ingresos 1.154.150 €. gastos 2.144.134 €. neto -989.983 €.

**Hitos:**
- 1.º de 24 en Sky Bet League One con 38 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos
- 3 goles de Basil Tuma en un partido contra Wrexham el 2028-09-16
- Pierde en penaltis (5-6) contra Birmingham City en Bristol Street Motors Trophy el 2028-10-03
- Bristol Street Motors Trophy: 2 partidos; el último, no ganado 1-1 contra Birmingham City el 2028-10-03
- Carabao Cup: 1 partidos; el último, no ganado 2-3 contra Huddersfield Town el 2028-08-01
- Copa FA inglesa: 1 partidos; el último, ganado 2-0 contra Welling United el 2028-10-28

Plantilla: 40 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
