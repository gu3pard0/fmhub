# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 2.º de 24 con 49 puntos (15V 4E 4D, 57-32).
- **Temporada en curso** (datos a 2028-12-09).
- **Oficiales:** 29 partidos, 18V 5E 6D, goles 69-40.
- Bristol Street Motors Trophy: 3 partidos, 1V 1E 1D.
- Carabao Cup: 1 partidos, 0V 0E 1D.
- Copa FA inglesa: 2 partidos, 2V 0E 0D.

- **Goleadores:** Alfie Matthews 13, Kwadwo Baah 9, Basil Tuma 9.
- **Asistencias:** Kwadwo Baah 7, Maxwell Statham 7, Cameron Harper 6.
- **Mejor nota (mín. 10 partidos):** Basil Tuma 7.36, Maxwell Statham 7.2, Max Cleworth 7.15.
- **Más partidos:** Alfie Matthews 28, Cameron Harper 27, Evan Anderson 26.
- **Mayor victoria:** 6-1 a Shrewsbury Town (2028-11-04). **Peor derrota:** 1-3 contra Wycombe Wanderers (2028-08-29).
- **Rachas:** 6 victorias seguidas, 15 sin perder; 8 porterías a cero.
- **Público en casa:** media de 4.494 espectadores.
- **Traspasos:** 8 fichajes (165.371.615 €) y 10 salidas (767.477.391 €).
- **Economía (suma mensual):** ingresos 3.563.480 €. gastos 3.461.216 €. neto 102.265 €.

**Hitos:**
- 2.º de 24 en Sky Bet League One con 49 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos
- 3 goles de Basil Tuma en un partido contra Wrexham el 2028-09-16
- 3 goles de Basil Tuma en un partido contra Shrewsbury Town el 2028-11-04
- Pierde en penaltis (5-6) contra Birmingham City en Bristol Street Motors Trophy el 2028-10-03
- Bristol Street Motors Trophy: 3 partidos; el último, ganado 3-0 contra Brentford el 2028-11-07
- Carabao Cup: 1 partidos; el último, no ganado 2-3 contra Huddersfield Town el 2028-08-01
- Copa FA inglesa: 2 partidos; el último, ganado 3-1 contra Scarborough Athletic el 2028-11-25

Plantilla: 41 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
