# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 1.º de 24 con 48 puntos (15V 3E 3D, 54-27).
- **Temporada en curso** (datos a 2028-11-29).
- **Oficiales:** 27 partidos, 18V 4E 5D, goles 66-35.
- Bristol Street Motors Trophy: 3 partidos, 1V 1E 1D.
- Carabao Cup: 1 partidos, 0V 0E 1D.
- Copa FA inglesa: 2 partidos, 2V 0E 0D.

- **Goleadores:** Alfie Matthews 12, Kwadwo Baah 9, Basil Tuma 9.
- **Asistencias:** Kwadwo Baah 7, Maxwell Statham 7, Jesús Belza 6.
- **Mejor nota (mín. 10 partidos):** Basil Tuma 7.48, Max Cleworth 7.23, Kwadwo Baah 7.21.
- **Más partidos:** Alfie Matthews 26, Mason Rees 26, Cameron Harper 25.
- **Mayor victoria:** 6-1 a Shrewsbury Town (2028-11-04). **Peor derrota:** 1-3 contra Wycombe Wanderers (2028-08-29).
- **Rachas:** 6 victorias seguidas, 15 sin perder; 8 porterías a cero.
- **Público en casa:** media de 4.494 espectadores.
- **Traspasos:** 8 fichajes (165.371.615 €) y 9 salidas (767.477.391 €).
- **Economía (suma mensual):** ingresos 1.820.055 €. gastos 2.871.155 €. neto -1.051.099 €.

**Hitos:**
- 1.º de 24 en Sky Bet League One con 48 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos
- 3 goles de Basil Tuma en un partido contra Wrexham el 2028-09-16
- 3 goles de Basil Tuma en un partido contra Shrewsbury Town el 2028-11-04
- Pierde en penaltis (5-6) contra Birmingham City en Bristol Street Motors Trophy el 2028-10-03
- Bristol Street Motors Trophy: 3 partidos; el último, ganado 3-0 contra Brentford el 2028-11-07
- Carabao Cup: 1 partidos; el último, no ganado 2-3 contra Huddersfield Town el 2028-08-01
- Copa FA inglesa: 2 partidos; el último, ganado 3-1 contra Scarborough Athletic el 2028-11-25

Plantilla: 41 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
