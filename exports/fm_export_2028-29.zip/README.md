# FM Hub: exportación de la temporada 2028/29

Partida de Football Manager 2024 de Airam: Adrián Varela, mánager del Dartford. Datos leídos del juego por FM Hub (memoria del juego en modo lectura, exportaciones de pantallas y tablas de carrera). Solo datos que el juego muestra.

## Archivos

- `temporada.json`: Metadatos de la temporada, clasificaciones (todas las cargadas), récords e hitos.
- `partidos.json`: Todos los partidos (oficiales y amistosos) con goles y, si existe, la alineación.
- `plantilla.json`: Todos los jugadores que pasaron por el club esa temporada, con estadísticas, contrato, valor y atributos.
- `traspasos.json`: Fichajes y salidas entre el 1 de julio y el 30 de junio.
- `economia.json`: Finanzas del club mes a mes y desglose de ingresos y gastos si se exportó desde FM.
- `resumen.md`: Resumen corto en texto, para pegar en una conversación.

## Cómo se relacionan

- **Jugador:** `iu` (identificador único de FM), igual en `plantilla.json`, `partidos.json` (goles y alineación) y `traspasos.json`.
- **Partido:** `partido_id` = `AAAA-MM-DD|local|visitante`, en `partidos.json` y en `plantilla.json` → `partido_a_partido`.
- **Temporada:** `AAAA/AA`, de julio a junio, en todos los archivos.

## Unidades

- Importes en **euros enteros** (`*_eur`). En la interfaz de FM24 en español, «m €» son **miles** de euros y «M €» millones; el campo `valor.texto` lo conserva tal cual y `min_eur`/`max_eur` ya están convertidos.
- Fechas ISO `AAAA-MM-DD` (fecha del juego). Minutos de juego enteros; el descuento va en `anadido`.
- Notas de 1 a 10. Atributos de 1 a 20. Distancias en km.

## Campos

### temporada.json
- `metadatos`: club, mánager, temporada (julio a junio), competición de liga, posición final, si la temporada está en curso, fecha de juego de los últimos datos, fecha de generación
- `clasificaciones`: {competición: [filas]}; fila = pos, club, j, g, e, p, gf, gc, dg, pts, propio (true en la fila del club), detalle (casa/fuera si FM lo da)
- `records`: balances (j, v, e, d, gf, gc) oficial, liga, casa, fuera, por competición y amistosos; mayor victoria, peor derrota, más espectadores, rachas (en partidos oficiales, con fechas desde/hasta), goles por franja de minutos, gol más rápido/tardío, hat-tricks, máximos de la plantilla (oficiales) e hitos en texto

### partidos.json
- `partido_id`: clave del partido: «AAAA-MM-DD|local|visitante» (la usan alineaciones y plantilla.partido_a_partido)
- `id_partido_fm`: id interno del partido en FM (puede faltar en partidos que vienen de exportaciones)
- `competicion / oficial`: nombre de la competición como en FM; oficial = false en amistosos
- `condicion`: local o visitante (del club)
- `rival`: nombre del rival
- `goles_local / goles_visitante`: marcador tal cual (tras la prórroga si la hubo)
- `goles_favor / goles_contra / resultado`: desde el punto de vista del club; resultado V, E o D (un empate decidido en penaltis es E: mira «penaltis»)
- `penaltis`: null o {a_favor, en_contra, gana, marcados_en_la_tanda: [{equipo, jugador, iu}]} (los penaltis de la tanda NO están en «goles»)
- `global`: null o marcador global de una eliminatoria a doble partido
- `espectadores`: público del partido
- `goles`: lista en orden: minuto, anadido (minutos de descuento: 90+3 = minuto 90, anadido 3), texto_minuto, equipo (club o «rival»), jugador, iu (null si no se resolvió), tipo (normal, penalti, en propia puerta: el jugador es quien la marcó en propia)
- `ronda`: ronda o jornada tal como la escribe el calendario exportado de FM («1/4 Final de la Carabao Cup», «Ida de la Semifinal de los Playoffs…»); null si no se exportó
- `formacion / formacion_rival`: sistema táctico del club y del rival según el calendario exportado de FM (null si no se exportó)
- `alineacion`: null si no hay datos; lista de jugadores del club que jugaron: iu, jugador, titular, minutos, goles, asistencias, amarillas, rojas, mvp (jugador del partido), nota (1-10), detalle (pases, xG, distancia en km, etc.), puesto (DF-C, MC, DL-C…), puesto_fuente (tu once / hueco de la táctica / posición natural / heredada del que sustituye / sin pareja) y sustituye_a (iu del jugador por el que entró)

### plantilla.json
- `iu`: identificador único del jugador en FM (el mismo en todos los archivos y temporadas)
- `nombre / nombre_completo / fecha_nacimiento / edad / nacionalidad / posicion / dorsal / altura_cm / peso_kg`: datos personales (edad, posición y dorsal según la última exportación de plantilla de la temporada)
- `estadisticas`: {tipo: {...}} con tipo = liga, copa (todas las copas nacionales juntas), continental, internacional (selección), amistosos, total (oficiales), año_natural (solo en la temporada en curso: año natural de enero a diciembre, no la temporada); campos partidos, titular, suplente, minutos, goles, asistencias, amarillas, rojas, mvp (veces jugador del partido), nota_media (1-10) y, según la fuente, porterías a cero, goles encajados, penaltis, xg, xa, pases, distancia_km, etc.
- `fuente_estadisticas`: de dónde salen: tabla de carrera de FM (cifras finales de la temporada) o memoria (temporada en curso, con más detalle)
- `goles_oficiales_en_partidos`: goles contados en partidos.json (comprobación cruzada)
- `xg / xg_segun`: goles esperados en la temporada y de qué exportación salen (puede ser de antes de acabar la temporada: mira el número de partidos)
- `sueldo_mes_eur`: sueldo al mes en euros
- `fin_contrato`: fecha de fin de contrato
- `cedido_a`: club al que está cedido, si lo está
- `valor`: {texto, min_eur, max_eur}: valor tal como lo muestra FM (rango si el ojeo no es completo); en FM24 en español «m €» son MILES de euros y «M €» millones
- `moral`: moral en la última exportación
- `datos_a_fecha`: fecha de juego (o intervalo de fechas) de la captura de donde salen sueldo, contrato, valor y atributos
- `atributos_inicio / atributos_final / cambios_atributos`: atributos visibles (1-20) en la primera y última captura de la temporada y diferencia; abreviaturas de FM en español (Cen = centros, Reg = regate, Rem = remate, Cab = cabezazos, Lej = tiros lejanos, Mar = marcaje, Dmq = desmarques, Pas = pases, Pen = penaltis, Ent = entradas, Vis = visión, Ant = anticipación, Dec = decisiones, Col = colocación, Ctr = control, Téc = técnica, Tal = talento, JEq = juego en equipo, Sac = sacrificio, Ace = aceleración, Agi = agilidad, Equ = equilibrio, Fue = fuerza, Res = resistencia, Vel = velocidad, Sal = salto, Fís = forma física natural, Lid = liderazgo, Val = valentía, Agr = agresividad, Det = determinación, Ser = serenidad, Cnc = concentración; porteros: Blo, Aér, Mdo, Com, Pue, Saq, 1v1, Ref, Exc, SAL, Puñ, Lib)
- `partido_a_partido`: null o lista por partido (partido_id, o varios_partidos = true si FM Hub leyó varios partidos juntos)

### traspasos.json
- `fecha`: fecha del traspaso
- `tipo`: fichaje o salida
- `cesion`: true si es cesión
- `jugador / iu`: jugador (iu puede ser null en jugadores que nunca se exportaron)
- `club`: el otro club
- `precio_eur`: importe del traspaso en euros tal como lo enseña el historial de traspasos de FM (0 = libre o cesión); primas de fichaje, comisiones de agentes y pagos aplazados no están aquí sino en economia.json
- `libre`: true si es libre
- `origen`: memoria (leído del juego) o varela.html (movimiento que la memoria de FM ya no conserva, copiado de la referencia de Airam hecha con las pantallas del juego)
- `cantera`: lista aparte: jugadores promovidos desde la cantera («Día de la cantera»); FM los apunta como altas sin club de origen, pero NO son fichajes

### economia.json
- `meses`: una fila por mes (AAAA-MM), en euros: saldo, presupuesto de fichajes (y lo que queda), presupuesto salarial y masa salarial por semana, ingresos y gastos totales y sin traspasos, gasto en sueldos, gasto neto en traspasos, neto del mes; en_curso = true si el mes aún no ha acabado
- `totales_meses`: suma de los meses de la temporada (euros)
- `desglose`: null o conceptos de ingresos y gastos de la pantalla de finanzas de FM (euros); parcial = true si la temporada aún no había acabado cuando se exportó

## Limitaciones de esta temporada

- 7 de 45 partidos sin alineación: FM Hub las tiene de los partidos jugados con él en marcha (desde julio de 2028) y de los calendarios exportados con la columna de jugadores.
- La clasificación de liga no está completa (temporada en curso o tabla sin abrir en FM).
- El último mes de economía está en curso y todavía cambiará.
