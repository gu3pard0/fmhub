# Dartford 2026/27 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 6.º de 24 con 74 puntos (21V 12E 15D, 95-76).
- **Oficiales:** 62 partidos, 29V 13E 20D, goles 123-99.
- Bristol Street Motors Trophy: 3 partidos, 1V 0E 2D.
- Carabao Cup: 7 partidos, 5V 0E 2D.
- Copa FA inglesa: 4 partidos, 2V 1E 1D.

- **Goleadores:** Alfie Matthews 16, Teddy Jenks 15, Kyle Ferguson 12.
- **Asistencias:** Joe Sbarra 24, Jack Smith 9, Mekhi Haughton-Parris 9.
- **Mejor nota (mín. 10 partidos):** Joe Sbarra 7.18, Kyle Ferguson 7.07, Teddy Jenks 7.02.
- **Más partidos:** Jack Smith 57, Tope Fadahunsi 54, Evan Anderson 53.
- **Mayor victoria:** 7-1 a Shrewsbury Town (2026-11-07). **Peor derrota:** 0-4 contra Barnsley (2027-01-02).
- **Rachas:** 4 victorias seguidas, 7 sin perder; 14 porterías a cero.
- **Público en casa:** media de 3.984 espectadores.
- **Traspasos:** 7 fichajes (80.000 €) y 12 salidas (0 €).
- **Economía (suma mensual):** ingresos 6.715.272 €. gastos 5.962.643 €. neto 752.628 €.

**Hitos:**
- 6.º de 24 en Sky Bet League One con 74 puntos
- Temporada anterior: 2.º en Sky Bet League Two con 90 puntos
- 3 goles de Kyle Ferguson en un partido contra Barnsley el 2026-10-11
- 3 goles de Tope Fadahunsi en un partido contra Fleetwood Town el 2026-12-29
- Bristol Street Motors Trophy: 3 partidos; el último, no ganado 1-2 contra Wycombe Wanderers el 2026-11-10
- Carabao Cup: 7 partidos; el último, no ganado 0-1 contra Newcastle United el 2027-02-03
- Copa FA inglesa: 4 partidos; el último, no ganado 3-6 contra Leicester City el 2027-01-06

Plantilla: 46 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
