# Dartford 2024/25 (FM24, mánager Adrián Varela)

- **Liga:** Vanarama National League, 1.º de 24 con 116 puntos (37V 5E 4D, 142-51).
- **Oficiales:** 52 partidos, 40V 6E 6D, goles 157-58.
- Copa FA inglesa: 3 partidos, 1V 1E 1D.
- Trofeo FA inglés: 3 partidos, 2V 0E 1D.

- **Goleadores:** Manny Adebowale 26, Alfie Matthews 19, Jordan Ponticelli 17.
- **Asistencias:** Ben Brookes 20, Jim Kellermann 14, Maxwell Statham 13.
- **Mejor nota (mín. 10 partidos):** Manny Adebowale 7.36, Ben Brookes 7.25, Luke Coulson 7.24.
- **Más partidos:** Sam Odaudu 44, Ben Brookes 42, Manny Adebowale 42.
- **Mayor victoria:** 8-2 a Spennymoor Town (2024-12-21). **Peor derrota:** 0-3 contra Oxford City (2024-08-31).
- **Rachas:** 9 victorias seguidas, 16 sin perder; 14 porterías a cero.
- **Público en casa:** media de 2.314 espectadores.
- **Traspasos:** 8 fichajes (0 €) y 5 salidas (0 €).
- **Economía (suma mensual):** ingresos 3.979.923 €. gastos 4.047.373 €. neto -67.452 €.

**Hitos:**
- 1.º de 24 en Vanarama National League con 116 puntos
- Temporada anterior: 1.º en Vanarama National League South con 116 puntos
- 3 goles de Manny Adebowale en un partido contra Spennymoor Town el 2024-08-06
- 3 goles de Alfie Matthews en un partido contra Spennymoor Town el 2024-12-21
- 3 goles de Tom Hewlett en un partido contra AFC Fylde el 2024-12-28
- 4 goles de Manny Adebowale en un partido contra Boreham Wood el 2025-01-04
- Copa FA inglesa: 3 partidos; el último, no ganado 1-2 contra Gillingham el 2024-11-20
- Trofeo FA inglés: 3 partidos; el último, no ganado 1-2 contra Crewe Alexandra el 2025-02-08

Plantilla: 39 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
