# Dartford 2023/24 (FM24, mánager Adrián Varela)

- **Liga:** Vanarama National League South, 1.º de 24 con 116 puntos (37V 5E 4D, 133-63).
- **Oficiales:** 56 partidos, 44V 6E 6D, goles 162-77.
- Copa FA inglesa: 6 partidos, 4V 1E 1D.
- Trofeo FA inglés: 4 partidos, 3V 0E 1D.

- **Goleadores:** Manny Adebowale 23, Fumnaya Shomotun 21, Luke Coulson 21.
- **Asistencias:** Fumnaya Shomotun 18, Sam Odaudu 17, Alfie Matthews 15.
- **Mejor nota (mín. 10 partidos):** Alfie Matthews 7.31, Sam Odaudu 7.26, Alex Wall 7.24.
- **Más partidos:** Fumnaya Shomotun 55, Manny Adebowale 53, Billy Terrell 52.
- **Mayor victoria:** 6-0 a Weymouth (2024-01-27). **Peor derrota:** 1-4 contra Truro City (2024-04-20).
- **Rachas:** 11 victorias seguidas, 15 sin perder; 18 porterías a cero.
- **Público en casa:** media de 1.246 espectadores.
- **Traspasos:** 5 fichajes (12.399 €) y 4 salidas (0 €).
- **Economía (suma mensual):** ingresos 2.313.239 €. gastos 3.066.665 €. neto -753.423 €.

**Hitos:**
- 1.º de 24 en Vanarama National League South con 116 puntos
- 3 goles de Luke Coulson en un partido contra Weston-super-Mare el 2023-10-17
- 3 goles de Manny Adebowale en un partido contra Bath City el 2024-01-13
- 3 goles de Charlie Sheringham en un partido contra Eastbourne Borough el 2024-04-01
- Copa FA inglesa: 6 partidos; el último, no ganado 3-5 contra AFC Fylde el 2023-12-02
- Trofeo FA inglés: 4 partidos; el último, no ganado 0-3 contra Darlington el 2024-02-10

Plantilla: 44 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).


# Dartford 2024/25 (FM24, mánager Adrián Varela)

- **Liga:** Vanarama National League, 1.º de 24 con 116 puntos (37V 5E 4D, 142-51).
- **Oficiales:** 52 partidos, 40V 6E 6D, goles 157-58.
- Copa FA inglesa: 3 partidos, 1V 1E 1D.
- Trofeo FA inglés: 3 partidos, 2V 0E 1D.

- **Goleadores:** Manny Adebowale 26, Alfie Matthews 19, Jordan Ponticelli 17.
- **Asistencias:** Ben Brookes 20, Jim Kellermann 14, Maxwell Statham 13.
- **Mejor nota (mín. 10 partidos):** Manny Adebowale 7.36, Ben Brookes 7.25, Luke Coulson 7.24.
- **Más partidos:** Sam Odaudu 44, Ben Brookes 42, Manny Adebowale 42.
- **Mayor victoria:** 8-2 a Spennymoor Town (2024-12-21). **Peor derrota:** 0-3 contra Oxford City (2024-08-31).
- **Rachas:** 9 victorias seguidas, 16 sin perder; 14 porterías a cero.
- **Público en casa:** media de 2.314 espectadores.
- **Traspasos:** 8 fichajes (0 €) y 5 salidas (0 €).
- **Economía (suma mensual):** ingresos 1.805.679 €. gastos 1.833.314 €. neto -27.636 €.

**Hitos:**
- 1.º de 24 en Vanarama National League con 116 puntos
- Temporada anterior: 1.º en Vanarama National League South con 116 puntos
- 3 goles de Manny Adebowale en un partido contra Spennymoor Town el 2024-08-06
- 3 goles de Alfie Matthews en un partido contra Spennymoor Town el 2024-12-21
- 3 goles de Tom Hewlett en un partido contra AFC Fylde el 2024-12-28
- 4 goles de Manny Adebowale en un partido contra Boreham Wood el 2025-01-04
- Copa FA inglesa: 3 partidos; el último, no ganado 1-2 contra Gillingham el 2024-11-20
- Trofeo FA inglés: 3 partidos; el último, no ganado 1-2 contra Crewe Alexandra el 2025-02-08

Plantilla: 39 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).


# Dartford 2025/26 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League Two, 2.º de 24 con 90 puntos (26V 12E 8D, 98-62).
- **Oficiales:** 54 partidos, 31V 13E 10D, goles 122-73.
- Bristol Street Motors Trophy: 5 partidos, 4V 1E 0D.
- Carabao Cup: 2 partidos, 1V 0E 1D.
- Copa FA inglesa: 1 partidos, 0V 0E 1D.

- **Goleadores:** Callum Powell 19, Alfie Matthews 17, Jordan Ponticelli 16.
- **Asistencias:** Ben Brookes 17, Alfie Matthews 14, Maxwell Statham 13.
- **Mejor nota (mín. 10 partidos):** Ben Brookes 7.04, Sam Odaudu 7.02, Jordan Ponticelli 7.0.
- **Más partidos:** Alfie Matthews 52, Tyla Dickinson 52, Jack Smith 49.
- **Mayor victoria:** 5-1 a Crystal Palace (2025-09-02). **Peor derrota:** 2-5 contra Gillingham (2025-09-13).
- **Rachas:** 7 victorias seguidas, 11 sin perder; 15 porterías a cero.
- **Público en casa:** media de 2.823 espectadores.
- **Traspasos:** 4 fichajes (177.999 €) y 6 salidas (7.000 €).
- **Economía (suma mensual):** ingresos 4.908.364 €. gastos 5.382.537 €. neto -474.174 €.

**Hitos:**
- 2.º de 24 en Sky Bet League Two con 90 puntos
- Temporada anterior: 1.º en Vanarama National League con 116 puntos
- Pierde en penaltis (10-11) contra Tottenham Hotspur en Bristol Street Motors Trophy el 2026-01-06
- Bristol Street Motors Trophy: 5 partidos; el último, no ganado 2-2 contra Tottenham Hotspur el 2026-01-06
- Carabao Cup: 2 partidos; el último, no ganado 1-3 contra Bristol City el 2025-08-26
- Copa FA inglesa: 1 partidos; el último, no ganado 2-3 contra Shrewsbury Town el 2025-11-01

Plantilla: 43 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).


# Dartford 2026/27 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 6.º de 24 con 74 puntos (21V 12E 15D, 95-76).
- **Oficiales:** 62 partidos, 29V 13E 20D, goles 123-99.
- Bristol Street Motors Trophy: 3 partidos, 1V 0E 2D.
- Carabao Cup: 7 partidos, 5V 0E 2D.
- Copa FA inglesa: 4 partidos, 2V 1E 1D.

- **Goleadores:** Alfie Matthews 16, Teddy Jenks 15, Kyle Ferguson 12.
- **Asistencias:** Joe Sbarra 24, Jack Smith 9, Mekhi Haughton-Parris 9.
- **Mejor nota (mín. 10 partidos):** Joe Sbarra 7.18, Kyle Ferguson 7.07, Teddy Jenks 7.02.
- **Más partidos:** Jack Smith 57, Tope Fadahunsi 54, Evan Anderson 53.
- **Mayor victoria:** 7-1 a Shrewsbury Town (2026-11-07). **Peor derrota:** 0-4 contra Barnsley (2027-01-02).
- **Rachas:** 4 victorias seguidas, 7 sin perder; 14 porterías a cero.
- **Público en casa:** media de 3.984 espectadores.
- **Traspasos:** 7 fichajes (80.000 €) y 12 salidas (0 €).
- **Economía (suma mensual):** ingresos 6.715.272 €. gastos 5.962.643 €. neto 752.628 €.

**Hitos:**
- 6.º de 24 en Sky Bet League One con 74 puntos
- Temporada anterior: 2.º en Sky Bet League Two con 90 puntos
- 3 goles de Kyle Ferguson en un partido contra Barnsley el 2026-10-11
- 3 goles de Tope Fadahunsi en un partido contra Fleetwood Town el 2026-12-29
- Bristol Street Motors Trophy: 3 partidos; el último, no ganado 1-2 contra Wycombe Wanderers el 2026-11-10
- Carabao Cup: 7 partidos; el último, no ganado 0-1 contra Newcastle United el 2027-02-03
- Copa FA inglesa: 4 partidos; el último, no ganado 3-6 contra Leicester City el 2027-01-06

Plantilla: 46 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).


# Dartford 2027/28 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 15.º de 24 con 60 puntos (16V 12E 18D, 84-78).
- **Oficiales:** 56 partidos, 18V 18E 20D, goles 100-92.
- Bristol Street Motors Trophy: 6 partidos, 1V 4E 1D.
- Carabao Cup: 2 partidos, 1V 0E 1D.
- Copa FA inglesa: 2 partidos, 0V 2E 0D.

- **Goleadores:** Tope Fadahunsi 11, Kiban Rai 9, Teddy Jenks 9.
- **Asistencias:** Kwadwo Baah 14, Mekhi Haughton-Parris 12, Jack Smith 7.
- **Mejor nota (mín. 10 partidos):** Tom Hewlett 7.3, Kyle Ferguson 7.06, Max Cleworth 7.0.
- **Más partidos:** Evan Anderson 53, Joe Knight 51, Jack Tucker 48.
- **Mayor victoria:** 7-1 a Colchester United (2028-02-26). **Peor derrota:** 2-5 contra Derby County (2027-10-12).
- **Rachas:** 4 victorias seguidas, 6 sin perder; 6 porterías a cero.
- **Público en casa:** media de 3.543 espectadores.
- **Traspasos:** 4 fichajes (0 €) y 6 salidas (52.387 €).
- **Economía (suma mensual):** ingresos 6.864.752 €. gastos 7.939.709 €. neto -1.074.957 €.

**Hitos:**
- 15.º de 24 en Sky Bet League One con 60 puntos
- Temporada anterior: 6.º en Sky Bet League One con 74 puntos
- 5 goles de Kyle Ferguson en un partido contra Derby County el 2027-12-18
- 3 goles de Tom Hewlett en un partido contra Peterborough United el 2028-02-29
- Pierde en penaltis (2-4) contra Forest Green Rovers en Bristol Street Motors Trophy el 2027-11-09
- Pierde en penaltis (3-4) contra AFC Wimbledon en Copa FA inglesa el 2027-11-17
- Gana en penaltis (4-3) contra AFC Wimbledon en Bristol Street Motors Trophy el 2027-11-30
- Gana en penaltis (4-3) contra Birmingham City en Bristol Street Motors Trophy el 2028-01-04
- Pierde en penaltis (3-5) contra Peterborough United en Bristol Street Motors Trophy el 2028-01-25
- Bristol Street Motors Trophy: 6 partidos; el último, no ganado 2-2 contra Peterborough United el 2028-01-25
- Carabao Cup: 2 partidos; el último, no ganado 0-1 contra Reading el 2027-08-24
- Copa FA inglesa: 2 partidos; el último, no ganado 1-1 contra AFC Wimbledon el 2027-11-17

Plantilla: 38 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).


# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 3.º de 24 con 20 puntos (6V 2E 1D, 22-13).
- **Temporada en curso** (datos a 2028-09-23).
- **Oficiales:** 11 partidos, 6V 2E 3D, goles 25-19.
- Bristol Street Motors Trophy: 1 partidos, 0V 0E 1D.
- Carabao Cup: 1 partidos, 0V 0E 1D.

- **Goleadores:** Tyler Cordner 4, Basil Tuma 4, Alfie Matthews 3.
- **Asistencias:** Kwadwo Baah 5, Jesús Belza 3, Jack Smith 3.
- **Mejor nota (mín. 10 partidos):** Kwadwo Baah 6.99, Jesús Belza 6.98, Joe Knight 6.89.
- **Más partidos:** Keanu Chalaye 13, Shamido Charles-Fyfield 12, Alfie Matthews 11.
- **Mayor victoria:** 3-0 a Wycombe Wanderers (2028-08-26). **Peor derrota:** 1-3 contra Wycombe Wanderers (2028-08-29).
- **Rachas:** 4 victorias seguidas, 4 sin perder; 2 porterías a cero.
- **Público en casa:** media de 4.758 espectadores.
- **Traspasos:** 3 fichajes (0 €) y 4 salidas (0 €).
- **Economía (suma mensual):** ingresos 2.146.353 €. gastos 1.660.952 €. neto 485.402 €.

**Hitos:**
- 3.º de 24 en Sky Bet League One con 20 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos
- 3 goles de Basil Tuma en un partido contra Wrexham el 2028-09-16
- Bristol Street Motors Trophy: 1 partidos; el último, no ganado 1-3 contra Wycombe Wanderers el 2028-08-29
- Carabao Cup: 1 partidos; el último, no ganado 2-3 contra Huddersfield Town el 2028-08-01

Plantilla: 40 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
