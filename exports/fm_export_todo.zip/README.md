# FM Hub: toda la partida (2023/24 a 2028/29)

Partida de Football Manager 2024 de Airam: Adrián Varela, mánager del Dartford. Una carpeta por temporada
(`AAAA-AA/`) con los mismos archivos que la exportación de una temporada: `README.md` (explica cada campo,
unidades y limitaciones), `temporada.json`, `partidos.json`, `plantilla.json`, `traspasos.json`, `economia.json`
y `resumen.md`. Los identificadores son comunes a todas las temporadas: `iu` del jugador, `partido_id`
(`AAAA-MM-DD|local|visitante`) y la temporada `AAAA/AA`. En la interfaz de FM24 en español, «m €» son miles
de euros; aquí los importes van en euros enteros.

`resumen.md`, en esta misma carpeta, junta los resúmenes cortos de todas las temporadas para pegarlos en una
conversación.
