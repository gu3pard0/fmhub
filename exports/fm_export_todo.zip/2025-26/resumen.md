# Dartford 2025/26 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League Two, 2.º de 24 con 90 puntos (26V 12E 8D, 98-62).
- **Oficiales:** 54 partidos, 31V 13E 10D, goles 122-73.
- Bristol Street Motors Trophy: 5 partidos, 4V 1E 0D.
- Carabao Cup: 2 partidos, 1V 0E 1D.
- Copa FA inglesa: 1 partidos, 0V 0E 1D.

- **Goleadores:** Callum Powell 19, Alfie Matthews 17, Jordan Ponticelli 16.
- **Asistencias:** Ben Brookes 17, Alfie Matthews 14, Maxwell Statham 13.
- **Mejor nota (mín. 10 partidos):** Ben Brookes 7.04, Sam Odaudu 7.02, Jordan Ponticelli 7.0.
- **Más partidos:** Alfie Matthews 52, Tyla Dickinson 52, Jack Smith 49.
- **Mayor victoria:** 5-1 a Crystal Palace (2025-09-02). **Peor derrota:** 2-5 contra Gillingham (2025-09-13).
- **Rachas:** 7 victorias seguidas, 11 sin perder; 15 porterías a cero.
- **Público en casa:** media de 2.823 espectadores.
- **Traspasos:** 4 fichajes (177.999 €) y 6 salidas (7.091 €).
- **Economía (suma mensual):** ingresos 3.918.913 €. gastos 3.800.630 €. neto 118.282 €.

**Hitos:**
- 2.º de 24 en Sky Bet League Two con 90 puntos
- Temporada anterior: 1.º en Vanarama National League con 116 puntos
- Pierde en penaltis (10-11) contra Tottenham Hotspur en Bristol Street Motors Trophy el 2026-01-06
- Bristol Street Motors Trophy: 5 partidos; el último, no ganado 2-2 contra Tottenham Hotspur el 2026-01-06
- Carabao Cup: 2 partidos; el último, no ganado 1-3 contra Bristol City el 2025-08-26
- Copa FA inglesa: 1 partidos; el último, no ganado 2-3 contra Shrewsbury Town el 2025-11-01

Plantilla: 44 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
