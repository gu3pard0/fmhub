# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 1.º de 24 con 39 puntos (12V 3E 1D, 40-20).
- **Temporada en curso** (datos a 2028-10-31).
- **Oficiales:** 20 partidos, 13V 4E 3D, goles 46-27.
- Bristol Street Motors Trophy: 2 partidos, 0V 1E 1D.
- Carabao Cup: 1 partidos, 0V 0E 1D.
- Copa FA inglesa: 1 partidos, 1V 0E 0D.

- **Goleadores:** Kwadwo Baah 8, Alfie Matthews 7, Basil Tuma 6.
- **Asistencias:** Kwadwo Baah 7, Jack Smith 6, Jesús Belza 4.
- **Mejor nota (mín. 10 partidos):** Basil Tuma 7.38, Kwadwo Baah 7.32, Maxwell Statham 7.12.
- **Más partidos:** Alfie Matthews 20, Evan Anderson 19, Mason Rees 19.
- **Mayor victoria:** 4-0 a Forest Green Rovers (2028-10-21). **Peor derrota:** 1-3 contra Wycombe Wanderers (2028-08-29).
- **Rachas:** 6 victorias seguidas, 13 sin perder; 6 porterías a cero.
- **Público en casa:** media de 4.628 espectadores.
- **Traspasos:** 4 fichajes (0 €) y 31 salidas (194.586 €).
- **Economía (suma mensual):** ingresos 1.723.508 €. gastos 2.443.071 €. neto -719.562 €.

**Hitos:**
- 1.º de 24 en Sky Bet League One con 39 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos
- 3 goles de Basil Tuma en un partido contra Wrexham el 2028-09-16
- Pierde en penaltis (5-6) contra Birmingham City en Bristol Street Motors Trophy el 2028-10-03
- Bristol Street Motors Trophy: 2 partidos; el último, no ganado 1-1 contra Birmingham City el 2028-10-03
- Carabao Cup: 1 partidos; el último, no ganado 2-3 contra Huddersfield Town el 2028-08-01
- Copa FA inglesa: 1 partidos; el último, ganado 2-0 contra Welling United el 2028-10-28

Plantilla: 40 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
