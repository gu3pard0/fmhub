# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 1.º de 24 con 103 puntos (32V 7E 6D, 117-53).
- **Temporada en curso** (datos a 2029-04-17).
- **Oficiales:** 52 partidos, 35V 8E 9D, goles 129-63.
- Bristol Street Motors Trophy: 3 partidos, 1V 1E 1D.
- Carabao Cup: 1 partidos, 0V 0E 1D.
- Copa FA inglesa: 3 partidos, 2V 0E 1D.

- **Goleadores:** Basil Tuma 20, Alfie Matthews 17, Kwadwo Baah 14.
- **Asistencias:** Kwadwo Baah 19, Cameron Harper 12, Jack Smith 11.
- **Mejor nota (mín. 10 partidos):** Basil Tuma 7.37, Maxwell Statham 7.23, Kwadwo Baah 7.18.
- **Más partidos:** Cameron Harper 48, Evan Anderson 48, Pele Arganese-McDermott 47.
- **Mayor victoria:** 6-0 a Port Vale (2028-12-26). **Peor derrota:** 1-4 contra Birmingham City (2029-03-10).
- **Rachas:** 10 victorias seguidas, 15 sin perder; 13 porterías a cero.
- **Público en casa:** media de 4.844 espectadores.
- **Traspasos:** 18 fichajes (4.861.816.629 €) y 18 salidas (1.379.677.842 €).
- **Economía (suma mensual):** ingresos 5.105.585 €. gastos 5.895.749 €. neto -790.164 €.

**Hitos:**
- 1.º de 24 en Sky Bet League One con 103 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos
- 3 goles de Basil Tuma en un partido contra Wrexham el 2028-09-16
- 3 goles de Basil Tuma en un partido contra Shrewsbury Town el 2028-11-04
- 3 goles de Basil Tuma en un partido contra Port Vale el 2028-12-26
- 4 goles de Basil Tuma en un partido contra Preston North End el 2029-02-20
- Pierde en penaltis (5-6) contra Birmingham City en Bristol Street Motors Trophy el 2028-10-03
- Bristol Street Motors Trophy: 3 partidos; el último, ganado 3-0 contra Brentford el 2028-11-07
- Carabao Cup: 1 partidos; el último, no ganado 2-3 contra Huddersfield Town el 2028-08-01
- Copa FA inglesa: 3 partidos; el último, no ganado 0-2 contra Newcastle United el 2029-01-10

Plantilla: 43 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
