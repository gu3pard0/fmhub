# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 1.º de 24 con 45 puntos (14V 3E 2D, 49-22).
- **Temporada en curso** (datos a 2028-11-18).
- **Oficiales:** 24 partidos, 16V 4E 4D, goles 58-29.
- Bristol Street Motors Trophy: 3 partidos, 1V 1E 1D.
- Carabao Cup: 1 partidos, 0V 0E 1D.
- Copa FA inglesa: 1 partidos, 1V 0E 0D.

- **Goleadores:** Kwadwo Baah 9, Basil Tuma 9, Alfie Matthews 8.
- **Asistencias:** Kwadwo Baah 7, Jack Smith 6, Maxwell Statham 6.
- **Mejor nota (mín. 10 partidos):** Basil Tuma 7.53, Kwadwo Baah 7.26, Max Cleworth 7.19.
- **Más partidos:** Alfie Matthews 23, Mason Rees 23, Cameron Harper 22.
- **Mayor victoria:** 6-1 a Shrewsbury Town (2028-11-04). **Peor derrota:** 1-3 contra Wycombe Wanderers (2028-08-29).
- **Rachas:** 6 victorias seguidas, 15 sin perder; 8 porterías a cero.
- **Público en casa:** media de 4.437 espectadores.
- **Traspasos:** 7 fichajes (165.371.615 €) y 9 salidas (767.477.391 €).
- **Economía (suma mensual):** ingresos 1.820.055 €. gastos 2.871.155 €. neto -1.051.099 €.

**Hitos:**
- 1.º de 24 en Sky Bet League One con 45 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos
- 3 goles de Basil Tuma en un partido contra Wrexham el 2028-09-16
- 3 goles de Basil Tuma en un partido contra Shrewsbury Town el 2028-11-04
- Pierde en penaltis (5-6) contra Birmingham City en Bristol Street Motors Trophy el 2028-10-03
- Bristol Street Motors Trophy: 3 partidos; el último, ganado 3-0 contra Brentford el 2028-11-07
- Carabao Cup: 1 partidos; el último, no ganado 2-3 contra Huddersfield Town el 2028-08-01
- Copa FA inglesa: 1 partidos; el último, ganado 2-0 contra Welling United el 2028-10-28

Plantilla: 41 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
