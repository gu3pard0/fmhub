# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 1.º de 24 con 84 puntos (26V 6E 4D, 93-42).
- **Temporada en curso** (datos a 2029-02-20).
- **Oficiales:** 43 partidos, 29V 7E 7D, goles 105-52.
- Bristol Street Motors Trophy: 3 partidos, 1V 1E 1D.
- Carabao Cup: 1 partidos, 0V 0E 1D.
- Copa FA inglesa: 3 partidos, 2V 0E 1D.

- **Goleadores:** Basil Tuma 17, Alfie Matthews 15, Kwadwo Baah 12.
- **Asistencias:** Kwadwo Baah 16, Cameron Harper 10, Maxwell Statham 10.
- **Mejor nota (mín. 10 partidos):** Basil Tuma 7.42, Maxwell Statham 7.23, Kwadwo Baah 7.18.
- **Más partidos:** Cameron Harper 40, Evan Anderson 40, Alfie Matthews 39.
- **Mayor victoria:** 6-0 a Port Vale (2028-12-26). **Peor derrota:** 1-3 contra Wycombe Wanderers (2028-08-29).
- **Rachas:** 7 victorias seguidas, 15 sin perder; 11 porterías a cero.
- **Público en casa:** media de 4.753 espectadores.
- **Traspasos:** 14 fichajes (2.425.813.472 €) y 17 salidas (1.379.656.990 €).
- **Economía (suma mensual):** ingresos 4.747.136 €. gastos 4.686.863 €. neto 60.273 €.

**Hitos:**
- 1.º de 24 en Sky Bet League One con 84 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos
- 3 goles de Basil Tuma en un partido contra Wrexham el 2028-09-16
- 3 goles de Basil Tuma en un partido contra Shrewsbury Town el 2028-11-04
- 3 goles de Basil Tuma en un partido contra Port Vale el 2028-12-26
- 4 goles de Basil Tuma en un partido contra Preston North End el 2029-02-20
- Pierde en penaltis (5-6) contra Birmingham City en Bristol Street Motors Trophy el 2028-10-03
- Bristol Street Motors Trophy: 3 partidos; el último, ganado 3-0 contra Brentford el 2028-11-07
- Carabao Cup: 1 partidos; el último, no ganado 2-3 contra Huddersfield Town el 2028-08-01
- Copa FA inglesa: 3 partidos; el último, no ganado 0-2 contra Newcastle United el 2029-01-10

Plantilla: 43 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
