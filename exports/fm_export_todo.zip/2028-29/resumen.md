# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 3.º de 24 con 20 puntos (6V 2E 1D, 22-13).
- **Temporada en curso** (datos a 2028-09-23).
- **Oficiales:** 11 partidos, 6V 2E 3D, goles 25-19.
- Bristol Street Motors Trophy: 1 partidos, 0V 0E 1D.
- Carabao Cup: 1 partidos, 0V 0E 1D.

- **Goleadores:** Tyler Cordner 4, Basil Tuma 4, Alfie Matthews 3.
- **Asistencias:** Kwadwo Baah 5, Jesús Belza 3, Jack Smith 3.
- **Mejor nota (mín. 10 partidos):** Kwadwo Baah 6.99, Jesús Belza 6.98, Joe Knight 6.89.
- **Más partidos:** Keanu Chalaye 13, Shamido Charles-Fyfield 12, Alfie Matthews 11.
- **Mayor victoria:** 3-0 a Wycombe Wanderers (2028-08-26). **Peor derrota:** 1-3 contra Wycombe Wanderers (2028-08-29).
- **Rachas:** 4 victorias seguidas, 4 sin perder; 2 porterías a cero.
- **Público en casa:** media de 4.758 espectadores.
- **Traspasos:** 3 fichajes (0 €) y 4 salidas (194.586 €).
- **Economía (suma mensual):** ingresos 2.146.353 €. gastos 1.660.952 €. neto 485.402 €.

**Hitos:**
- 3.º de 24 en Sky Bet League One con 20 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos
- 3 goles de Basil Tuma en un partido contra Wrexham el 2028-09-16
- Bristol Street Motors Trophy: 1 partidos; el último, no ganado 1-3 contra Wycombe Wanderers el 2028-08-29
- Carabao Cup: 1 partidos; el último, no ganado 2-3 contra Huddersfield Town el 2028-08-01

Plantilla: 40 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
