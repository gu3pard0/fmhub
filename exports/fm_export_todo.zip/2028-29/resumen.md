# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 1.º de 24 con 100 puntos (31V 7E 5D, 113-50).
- **Temporada en curso** (datos a 2029-04-07).
- **Oficiales:** 50 partidos, 34V 8E 8D, goles 125-60.
- Bristol Street Motors Trophy: 3 partidos, 1V 1E 1D.
- Carabao Cup: 1 partidos, 0V 0E 1D.
- Copa FA inglesa: 3 partidos, 2V 0E 1D.

- **Goleadores:** Basil Tuma 19, Alfie Matthews 17, Kwadwo Baah 14.
- **Asistencias:** Kwadwo Baah 18, Cameron Harper 12, Jack Smith 11.
- **Mejor nota (mín. 10 partidos):** Basil Tuma 7.32, Maxwell Statham 7.23, Kwadwo Baah 7.18.
- **Más partidos:** Evan Anderson 47, Cameron Harper 46, Pele Arganese-McDermott 45.
- **Mayor victoria:** 6-0 a Port Vale (2028-12-26). **Peor derrota:** 1-4 contra Birmingham City (2029-03-10).
- **Rachas:** 10 victorias seguidas, 15 sin perder; 13 porterías a cero.
- **Público en casa:** media de 4.824 espectadores.
- **Traspasos:** 15 fichajes (4.415.106.741 €) y 17 salidas (1.379.677.842 €).
- **Economía (suma mensual):** ingresos 5.105.585 €. gastos 5.895.749 €. neto -790.164 €.

**Hitos:**
- 1.º de 24 en Sky Bet League One con 100 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos
- 3 goles de Basil Tuma en un partido contra Wrexham el 2028-09-16
- 3 goles de Basil Tuma en un partido contra Shrewsbury Town el 2028-11-04
- 3 goles de Basil Tuma en un partido contra Port Vale el 2028-12-26
- 4 goles de Basil Tuma en un partido contra Preston North End el 2029-02-20
- Pierde en penaltis (5-6) contra Birmingham City en Bristol Street Motors Trophy el 2028-10-03
- Bristol Street Motors Trophy: 3 partidos; el último, ganado 3-0 contra Brentford el 2028-11-07
- Carabao Cup: 1 partidos; el último, no ganado 2-3 contra Huddersfield Town el 2028-08-01
- Copa FA inglesa: 3 partidos; el último, no ganado 0-2 contra Newcastle United el 2029-01-10

Plantilla: 43 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
