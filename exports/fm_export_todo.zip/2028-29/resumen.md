# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 4.º de 24 con 13 puntos (4V 2E 1D, 14-8).
- **Temporada en curso** (datos a 2028-09-09).
- **Oficiales:** 9 partidos, 4V 2E 3D, goles 17-14.
- Bristol Street Motors Trophy: 1 partidos, 0V 0E 1D.
- Carabao Cup: 1 partidos, 0V 0E 1D.

- **Goleadores:** Alfie Matthews 3, Joe Knight 3, Tyler Cordner 3.
- **Asistencias:** Kwadwo Baah 4, Jack Smith 3, Keanu Chalaye 1.
- **Mejor nota (mín. 10 partidos):** Shamido Charles-Fyfield 6.85, Keanu Chalaye 6.62.
- **Más partidos:** Keanu Chalaye 11, Shamido Charles-Fyfield 10, Alfie Matthews 9.
- **Mayor victoria:** 3-0 a Wycombe Wanderers (2028-08-26). **Peor derrota:** 1-3 contra Wycombe Wanderers (2028-08-29).
- **Rachas:** 2 victorias seguidas, 4 sin perder; 2 porterías a cero.
- **Público en casa:** media de 4.618 espectadores.
- **Traspasos:** 3 fichajes (0 €) y 4 salidas (0 €).
- **Economía (suma mensual):** ingresos 2.146.353 €. gastos 1.660.952 €. neto 485.402 €.

**Hitos:**
- 4.º de 24 en Sky Bet League One con 13 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos
- Bristol Street Motors Trophy: 1 partidos; el último, no ganado 1-3 contra Wycombe Wanderers el 2028-08-29
- Carabao Cup: 1 partidos; el último, no ganado 2-3 contra Huddersfield Town el 2028-08-01

Plantilla: 40 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
