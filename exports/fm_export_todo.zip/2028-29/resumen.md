# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 17.º de 24 con 0 puntos (0V 0E 1D, 1-2).
- **Temporada en curso** (datos a 2028-07-29).
- **Oficiales:** 1 partidos, 0V 0E 1D, goles 1-2.

- **Goleadores:** Shamido Charles-Fyfield 1, Tope Fadahunsi 1.
- **Asistencias:** Joe Knight 1.
- **Mejor nota (mín. 10 partidos):** —.
- **Más partidos:** Alfie Matthews 1, Cameron Harper 1, Evan Anderson 1.
- **Mayor victoria:** 1-2 a Birmingham City (2028-07-29). **Peor derrota:** 1-2 contra Birmingham City (2028-07-29).
- **Rachas:** 0 victorias seguidas, 0 sin perder; 0 porterías a cero.
- **Público en casa:** media de 4.670 espectadores.
- **Traspasos:** 2 fichajes (0 €) y 4 salidas (0 €).
- **Economía (suma mensual):** ingresos 96.547 €. gastos 428.084 €. neto -331.537 €.

**Hitos:**
- 17.º de 24 en Sky Bet League One con 0 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos

Plantilla: 39 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
