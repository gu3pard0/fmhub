# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 1.º de 22 con 52 puntos (16V 4E 4D, 58-32).
- **Temporada en curso** (datos a 2028-12-12).
- **Oficiales:** 30 partidos, 19V 5E 6D, goles 70-40.
- Bristol Street Motors Trophy: 3 partidos, 1V 1E 1D.
- Carabao Cup: 1 partidos, 0V 0E 1D.
- Copa FA inglesa: 2 partidos, 2V 0E 0D.

- **Goleadores:** Alfie Matthews 13, Kwadwo Baah 9, Basil Tuma 9.
- **Asistencias:** Jack Smith 7, Kwadwo Baah 7, Maxwell Statham 7.
- **Mejor nota (mín. 10 partidos):** Basil Tuma 7.31, Maxwell Statham 7.21, Max Cleworth 7.15.
- **Más partidos:** Alfie Matthews 29, Cameron Harper 28, Evan Anderson 27.
- **Mayor victoria:** 6-1 a Shrewsbury Town (2028-11-04). **Peor derrota:** 1-3 contra Wycombe Wanderers (2028-08-29).
- **Rachas:** 6 victorias seguidas, 15 sin perder; 9 porterías a cero.
- **Público en casa:** media de 4.547 espectadores.
- **Traspasos:** 9 fichajes (2.114.841.528 €) y 9 salidas (767.477.391 €).
- **Economía (suma mensual):** ingresos 2.502.771 €. gastos 3.436.857 €. neto -934.086 €.

**Hitos:**
- 1.º de 22 en Sky Bet League One con 52 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos
- 3 goles de Basil Tuma en un partido contra Wrexham el 2028-09-16
- 3 goles de Basil Tuma en un partido contra Shrewsbury Town el 2028-11-04
- Pierde en penaltis (5-6) contra Birmingham City en Bristol Street Motors Trophy el 2028-10-03
- Bristol Street Motors Trophy: 3 partidos; el último, ganado 3-0 contra Brentford el 2028-11-07
- Carabao Cup: 1 partidos; el último, no ganado 2-3 contra Huddersfield Town el 2028-08-01
- Copa FA inglesa: 2 partidos; el último, ganado 3-1 contra Scarborough Athletic el 2028-11-25

Plantilla: 41 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
