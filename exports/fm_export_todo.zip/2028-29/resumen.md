# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 3.º de 24 con 17 puntos (5V 2E 1D, 19-11).
- **Temporada en curso** (datos a 2028-09-16).
- **Oficiales:** 10 partidos, 5V 2E 3D, goles 22-17.
- Bristol Street Motors Trophy: 1 partidos, 0V 0E 1D.
- Carabao Cup: 1 partidos, 0V 0E 1D.

- **Goleadores:** Tyler Cordner 4, Basil Tuma 4, Alfie Matthews 3.
- **Asistencias:** Kwadwo Baah 5, Jack Smith 3, Joe Knight 2.
- **Mejor nota (mín. 10 partidos):** Joe Knight 6.91, Shamido Charles-Fyfield 6.88, Cameron Harper 6.76.
- **Más partidos:** Keanu Chalaye 12, Shamido Charles-Fyfield 11, Alfie Matthews 10.
- **Mayor victoria:** 3-0 a Wycombe Wanderers (2028-08-26). **Peor derrota:** 1-3 contra Wycombe Wanderers (2028-08-29).
- **Rachas:** 3 victorias seguidas, 4 sin perder; 2 porterías a cero.
- **Público en casa:** media de 4.721 espectadores.
- **Traspasos:** 3 fichajes (0 €) y 4 salidas (0 €).
- **Economía (suma mensual):** ingresos 2.146.353 €. gastos 1.660.952 €. neto 485.402 €.

**Hitos:**
- 3.º de 24 en Sky Bet League One con 17 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos
- 3 goles de Basil Tuma en un partido contra Wrexham el 2028-09-16
- Bristol Street Motors Trophy: 1 partidos; el último, no ganado 1-3 contra Wycombe Wanderers el 2028-08-29
- Carabao Cup: 1 partidos; el último, no ganado 2-3 contra Huddersfield Town el 2028-08-01

Plantilla: 40 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
