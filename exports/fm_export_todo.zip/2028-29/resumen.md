# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 10.º de 24 con 8 puntos (2V 2E 1D, 10-7).
- **Temporada en curso** (datos a 2028-08-26).
- **Oficiales:** 6 partidos, 2V 2E 2D, goles 12-10.
- Carabao Cup: 1 partidos, 0V 0E 1D.

- **Goleadores:** Tyler Cordner 3, Shamido Charles-Fyfield 2, Alfie Matthews 2.
- **Asistencias:** Kwadwo Baah 3, Jack Smith 2, Keanu Chalaye 1.
- **Mejor nota (mín. 10 partidos):** —.
- **Más partidos:** Keanu Chalaye 8, Ryan Evans 8, Shamido Charles-Fyfield 7.
- **Mayor victoria:** 3-0 a Wycombe Wanderers (2028-08-26). **Peor derrota:** 2-3 contra Huddersfield Town (2028-08-01).
- **Rachas:** 1 victorias seguidas, 4 sin perder; 1 porterías a cero.
- **Público en casa:** media de 4.618 espectadores.
- **Traspasos:** 3 fichajes (0 €) y 4 salidas (0 €).
- **Economía (suma mensual):** ingresos 1.839.972 €. gastos 1.018.145 €. neto 821.827 €.

**Hitos:**
- 10.º de 24 en Sky Bet League One con 8 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos
- Carabao Cup: 1 partidos; el último, no ganado 2-3 contra Huddersfield Town el 2028-08-01

Plantilla: 40 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
