# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** sin clasificación guardada.
- **Temporada en curso** (datos a 2028-07-15).
- **Oficiales:** 0 partidos, 0V 0E 0D, goles 0-0.

- **Goleadores:** —.
- **Asistencias:** —.
- **Mejor nota (mín. 10 partidos):** —.
- **Más partidos:** —.
- **Traspasos:** 1 fichajes (0 €) y 3 salidas (0 €).
- **Economía (suma mensual):** ingresos 96.547 €. gastos 428.084 €. neto -331.537 €.

Plantilla: 38 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
