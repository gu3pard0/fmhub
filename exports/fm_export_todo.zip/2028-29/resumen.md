# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 17.º de 24 con 0 puntos (0V 0E 1D, 1-2).
- **Temporada en curso** (datos a 2028-08-01).
- **Oficiales:** 2 partidos, 0V 0E 2D, goles 3-5.
- Carabao Cup: 1 partidos, 0V 0E 1D.

- **Goleadores:** Jesús Belza 1, Mekhi Haughton-Parris 1, Tope Fadahunsi 1.
- **Asistencias:** Jack Smith 1, Joe Knight 1.
- **Mejor nota (mín. 10 partidos):** —.
- **Más partidos:** Alfie Matthews 2, Cameron Harper 2, Evan Anderson 2.
- **Mayor victoria:** 2-3 a Huddersfield Town (2028-08-01). **Peor derrota:** 2-3 contra Huddersfield Town (2028-08-01).
- **Rachas:** 0 victorias seguidas, 0 sin perder; 0 porterías a cero.
- **Público en casa:** media de 4.670 espectadores.
- **Traspasos:** 2 fichajes (0 €) y 4 salidas (0 €).
- **Economía (suma mensual):** ingresos 1.839.972 €. gastos 1.018.145 €. neto 821.827 €.

**Hitos:**
- 17.º de 24 en Sky Bet League One con 0 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos
- Carabao Cup: 1 partidos; el último, no ganado 2-3 contra Huddersfield Town el 2028-08-01

Plantilla: 39 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
