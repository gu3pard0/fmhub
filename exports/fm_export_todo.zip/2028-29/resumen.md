# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 1.º de 24 con 29 puntos (9V 2E 1D, 30-16).
- **Temporada en curso** (datos a 2028-10-14).
- **Oficiales:** 15 partidos, 9V 3E 3D, goles 34-23.
- Bristol Street Motors Trophy: 2 partidos, 0V 1E 1D.
- Carabao Cup: 1 partidos, 0V 0E 1D.

- **Goleadores:** Kwadwo Baah 5, Alfie Matthews 4, Tope Fadahunsi 4.
- **Asistencias:** Kwadwo Baah 7, Jack Smith 4, Jesús Belza 4.
- **Mejor nota (mín. 10 partidos):** Kwadwo Baah 7.25, Jack Smith 7.04, Jesús Belza 7.01.
- **Más partidos:** Keanu Chalaye 16, Alfie Matthews 15, Evan Anderson 15.
- **Mayor victoria:** 3-0 a Wycombe Wanderers (2028-08-26). **Peor derrota:** 1-3 contra Wycombe Wanderers (2028-08-29).
- **Rachas:** 5 victorias seguidas, 8 sin perder; 3 porterías a cero.
- **Público en casa:** media de 4.305 espectadores.
- **Traspasos:** 4 fichajes (0 €) y 4 salidas (194.586 €).
- **Economía (suma mensual):** ingresos 1.154.150 €. gastos 2.144.134 €. neto -989.983 €.

**Hitos:**
- 1.º de 24 en Sky Bet League One con 29 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos
- 3 goles de Basil Tuma en un partido contra Wrexham el 2028-09-16
- Pierde en penaltis (5-6) contra Birmingham City en Bristol Street Motors Trophy el 2028-10-03
- Bristol Street Motors Trophy: 2 partidos; el último, no ganado 1-1 contra Birmingham City el 2028-10-03
- Carabao Cup: 1 partidos; el último, no ganado 2-3 contra Huddersfield Town el 2028-08-01

Plantilla: 40 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
