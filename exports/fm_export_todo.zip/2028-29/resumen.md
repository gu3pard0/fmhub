# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 1.º de 24 con 42 puntos (13V 3E 1D, 46-21).
- **Temporada en curso** (datos a 2028-11-07).
- **Oficiales:** 22 partidos, 15V 4E 3D, goles 55-28.
- Bristol Street Motors Trophy: 3 partidos, 1V 1E 1D.
- Carabao Cup: 1 partidos, 0V 0E 1D.
- Copa FA inglesa: 1 partidos, 1V 0E 0D.

- **Goleadores:** Basil Tuma 9, Kwadwo Baah 8, Alfie Matthews 7.
- **Asistencias:** Kwadwo Baah 7, Jack Smith 6, Maxwell Statham 6.
- **Mejor nota (mín. 10 partidos):** Basil Tuma 7.61, Kwadwo Baah 7.3, Maxwell Statham 7.19.
- **Más partidos:** Alfie Matthews 21, Mason Rees 21, Cameron Harper 20.
- **Mayor victoria:** 6-1 a Shrewsbury Town (2028-11-04). **Peor derrota:** 1-3 contra Wycombe Wanderers (2028-08-29).
- **Rachas:** 6 victorias seguidas, 15 sin perder; 7 porterías a cero.
- **Público en casa:** media de 4.346 espectadores.
- **Traspasos:** 4 fichajes (0 €) y 32 salidas (194.586 €).
- **Economía (suma mensual):** ingresos 1.820.055 €. gastos 2.871.155 €. neto -1.051.099 €.

**Hitos:**
- 1.º de 24 en Sky Bet League One con 42 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos
- 3 goles de Basil Tuma en un partido contra Wrexham el 2028-09-16
- 3 goles de Basil Tuma en un partido contra Shrewsbury Town el 2028-11-04
- Pierde en penaltis (5-6) contra Birmingham City en Bristol Street Motors Trophy el 2028-10-03
- Bristol Street Motors Trophy: 3 partidos; el último, ganado 3-0 contra Brentford el 2028-11-07
- Carabao Cup: 1 partidos; el último, no ganado 2-3 contra Huddersfield Town el 2028-08-01
- Copa FA inglesa: 1 partidos; el último, ganado 2-0 contra Welling United el 2028-10-28

Plantilla: 41 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
