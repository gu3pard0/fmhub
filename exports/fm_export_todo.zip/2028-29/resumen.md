# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 1.º de 24 con 63 puntos (19V 6E 4D, 71-35).
- **Temporada en curso** (datos a 2029-01-06).
- **Oficiales:** 35 partidos, 22V 7E 6D, goles 83-43.
- Bristol Street Motors Trophy: 3 partidos, 1V 1E 1D.
- Carabao Cup: 1 partidos, 0V 0E 1D.
- Copa FA inglesa: 2 partidos, 2V 0E 0D.

- **Goleadores:** Alfie Matthews 13, Basil Tuma 12, Andre Brooks 12.
- **Asistencias:** Kwadwo Baah 11, Cameron Harper 8, Jack Smith 8.
- **Mejor nota (mín. 10 partidos):** Andre Brooks 7.3, Basil Tuma 7.27, Maxwell Statham 7.2.
- **Más partidos:** Alfie Matthews 32, Cameron Harper 32, Evan Anderson 32.
- **Mayor victoria:** 6-0 a Port Vale (2028-12-26). **Peor derrota:** 1-3 contra Wycombe Wanderers (2028-08-29).
- **Rachas:** 6 victorias seguidas, 15 sin perder; 11 porterías a cero.
- **Público en casa:** media de 4.678 espectadores.
- **Traspasos:** 11 fichajes (2.114.841.528 €) y 16 salidas (1.224.144.128 €).
- **Economía (suma mensual):** ingresos 3.003.711 €. gastos 4.096.802 €. neto -1.093.091 €.

**Hitos:**
- 1.º de 24 en Sky Bet League One con 63 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos
- 3 goles de Basil Tuma en un partido contra Wrexham el 2028-09-16
- 3 goles de Basil Tuma en un partido contra Shrewsbury Town el 2028-11-04
- 3 goles de Basil Tuma en un partido contra Port Vale el 2028-12-26
- Pierde en penaltis (5-6) contra Birmingham City en Bristol Street Motors Trophy el 2028-10-03
- Bristol Street Motors Trophy: 3 partidos; el último, ganado 3-0 contra Brentford el 2028-11-07
- Carabao Cup: 1 partidos; el último, no ganado 2-3 contra Huddersfield Town el 2028-08-01
- Copa FA inglesa: 2 partidos; el último, ganado 3-1 contra Scarborough Athletic el 2028-11-25

Plantilla: 43 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
