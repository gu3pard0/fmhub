# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 3.º de 24 con 23 puntos (7V 2E 1D, 24-14).
- **Temporada en curso** (datos a 2028-09-30).
- **Oficiales:** 12 partidos, 7V 2E 3D, goles 27-20.
- Bristol Street Motors Trophy: 1 partidos, 0V 0E 1D.
- Carabao Cup: 1 partidos, 0V 0E 1D.

- **Goleadores:** Tope Fadahunsi 4, Tyler Cordner 4, Basil Tuma 4.
- **Asistencias:** Kwadwo Baah 7, Jesús Belza 3, Jack Smith 3.
- **Mejor nota (mín. 10 partidos):** Kwadwo Baah 7.13, Jack Smith 6.98, Tyler Cordner 6.97.
- **Más partidos:** Keanu Chalaye 14, Ryan Evans 13, Shamido Charles-Fyfield 13.
- **Mayor victoria:** 3-0 a Wycombe Wanderers (2028-08-26). **Peor derrota:** 1-3 contra Wycombe Wanderers (2028-08-29).
- **Rachas:** 5 victorias seguidas, 5 sin perder; 2 porterías a cero.
- **Público en casa:** media de 4.758 espectadores.
- **Traspasos:** 4 fichajes (0 €) y 4 salidas (194.586 €).
- **Economía (suma mensual):** ingresos 837.674 €. gastos 1.606.569 €. neto -768.894 €.

**Hitos:**
- 3.º de 24 en Sky Bet League One con 23 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos
- 3 goles de Basil Tuma en un partido contra Wrexham el 2028-09-16
- Bristol Street Motors Trophy: 1 partidos; el último, no ganado 1-3 contra Wycombe Wanderers el 2028-08-29
- Carabao Cup: 1 partidos; el último, no ganado 2-3 contra Huddersfield Town el 2028-08-01

Plantilla: 40 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
