# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 1.º de 24 con 66 puntos (20V 6E 4D, 76-36).
- **Temporada en curso** (datos a 2029-01-13).
- **Oficiales:** 37 partidos, 23V 7E 7D, goles 88-46.
- Bristol Street Motors Trophy: 3 partidos, 1V 1E 1D.
- Carabao Cup: 1 partidos, 0V 0E 1D.
- Copa FA inglesa: 3 partidos, 2V 0E 1D.

- **Goleadores:** Alfie Matthews 14, Basil Tuma 12, Kwadwo Baah 10.
- **Asistencias:** Kwadwo Baah 11, Maxwell Statham 10, Cameron Harper 8.
- **Mejor nota (mín. 10 partidos):** Basil Tuma 7.27, Maxwell Statham 7.23, Max Cleworth 7.2.
- **Más partidos:** Alfie Matthews 34, Cameron Harper 34, Evan Anderson 34.
- **Mayor victoria:** 6-0 a Port Vale (2028-12-26). **Peor derrota:** 1-3 contra Wycombe Wanderers (2028-08-29).
- **Rachas:** 6 victorias seguidas, 15 sin perder; 11 porterías a cero.
- **Público en casa:** media de 4.678 espectadores.
- **Traspasos:** 13 fichajes (2.280.213.148 €) y 17 salidas (1.379.656.990 €).
- **Economía (suma mensual):** ingresos 3.003.711 €. gastos 4.096.802 €. neto -1.093.091 €.

**Hitos:**
- 1.º de 24 en Sky Bet League One con 66 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos
- 3 goles de Basil Tuma en un partido contra Wrexham el 2028-09-16
- 3 goles de Basil Tuma en un partido contra Shrewsbury Town el 2028-11-04
- 3 goles de Basil Tuma en un partido contra Port Vale el 2028-12-26
- Pierde en penaltis (5-6) contra Birmingham City en Bristol Street Motors Trophy el 2028-10-03
- Bristol Street Motors Trophy: 3 partidos; el último, ganado 3-0 contra Brentford el 2028-11-07
- Carabao Cup: 1 partidos; el último, no ganado 2-3 contra Huddersfield Town el 2028-08-01
- Copa FA inglesa: 3 partidos; el último, no ganado 0-2 contra Newcastle United el 2029-01-10

Plantilla: 43 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
