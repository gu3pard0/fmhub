# Dartford 2028/29 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 1.º de 24 con 26 puntos (8V 2E 1D, 28-16).
- **Temporada en curso** (datos a 2028-10-07).
- **Oficiales:** 14 partidos, 8V 3E 3D, goles 32-23.
- Bristol Street Motors Trophy: 2 partidos, 0V 1E 1D.
- Carabao Cup: 1 partidos, 0V 0E 1D.

- **Goleadores:** Tope Fadahunsi 4, Kwadwo Baah 4, Teddy Jenks 4.
- **Asistencias:** Kwadwo Baah 7, Jack Smith 4, Jesús Belza 3.
- **Mejor nota (mín. 10 partidos):** Kwadwo Baah 7.27, Jack Smith 7.01, Jesús Belza 6.95.
- **Más partidos:** Alfie Matthews 14, Evan Anderson 14, Keanu Chalaye 14.
- **Mayor victoria:** 3-0 a Wycombe Wanderers (2028-08-26). **Peor derrota:** 1-3 contra Wycombe Wanderers (2028-08-29).
- **Rachas:** 5 victorias seguidas, 7 sin perder; 2 porterías a cero.
- **Público en casa:** media de 4.151 espectadores.
- **Traspasos:** 4 fichajes (0 €) y 4 salidas (194.586 €).
- **Economía (suma mensual):** ingresos 2.581.099 €. gastos 2.196.630 €. neto 384.470 €.

**Hitos:**
- 1.º de 24 en Sky Bet League One con 26 puntos
- Temporada anterior: 15.º en Sky Bet League One con 60 puntos
- 3 goles de Basil Tuma en un partido contra Wrexham el 2028-09-16
- Pierde en penaltis (5-6) contra Birmingham City en Bristol Street Motors Trophy el 2028-10-03
- Bristol Street Motors Trophy: 2 partidos; el último, no ganado 1-1 contra Birmingham City el 2028-10-03
- Carabao Cup: 1 partidos; el último, no ganado 2-3 contra Huddersfield Town el 2028-08-01

Plantilla: 40 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
