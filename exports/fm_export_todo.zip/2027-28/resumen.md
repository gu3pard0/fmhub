# Dartford 2027/28 (FM24, mánager Adrián Varela)

- **Liga:** Sky Bet League One, 15.º de 24 con 60 puntos (16V 12E 18D, 84-78).
- **Oficiales:** 56 partidos, 18V 18E 20D, goles 100-92.
- Bristol Street Motors Trophy: 6 partidos, 1V 4E 1D.
- Carabao Cup: 2 partidos, 1V 0E 1D.
- Copa FA inglesa: 2 partidos, 0V 2E 0D.

- **Goleadores:** Tope Fadahunsi 11, Kiban Rai 9, Teddy Jenks 9.
- **Asistencias:** Kwadwo Baah 14, Mekhi Haughton-Parris 12, Jack Smith 7.
- **Mejor nota (mín. 10 partidos):** Tom Hewlett 7.3, Kyle Ferguson 7.06, Max Cleworth 7.0.
- **Más partidos:** Evan Anderson 53, Joe Knight 51, Jack Tucker 48.
- **Mayor victoria:** 7-1 a Colchester United (2028-02-26). **Peor derrota:** 2-5 contra Derby County (2027-10-12).
- **Rachas:** 4 victorias seguidas, 6 sin perder; 6 porterías a cero.
- **Público en casa:** media de 3.543 espectadores.
- **Traspasos:** 4 fichajes (0 €) y 6 salidas (52.387 €).
- **Economía (suma mensual):** ingresos 6.738.514 €. gastos 7.707.077 €. neto -968.563 €.

**Hitos:**
- 15.º de 24 en Sky Bet League One con 60 puntos
- Temporada anterior: 6.º en Sky Bet League One con 74 puntos
- 5 goles de Kyle Ferguson en un partido contra Derby County el 2027-12-18
- 3 goles de Tom Hewlett en un partido contra Peterborough United el 2028-02-29
- Pierde en penaltis (2-4) contra Forest Green Rovers en Bristol Street Motors Trophy el 2027-11-09
- Pierde en penaltis (3-4) contra AFC Wimbledon en Copa FA inglesa el 2027-11-17
- Gana en penaltis (4-3) contra AFC Wimbledon en Bristol Street Motors Trophy el 2027-11-30
- Gana en penaltis (4-3) contra Birmingham City en Bristol Street Motors Trophy el 2028-01-04
- Pierde en penaltis (3-5) contra Peterborough United en Bristol Street Motors Trophy el 2028-01-25
- Bristol Street Motors Trophy: 6 partidos; el último, no ganado 2-2 contra Peterborough United el 2028-01-25
- Carabao Cup: 2 partidos; el último, no ganado 0-1 contra Reading el 2027-08-24
- Copa FA inglesa: 2 partidos; el último, no ganado 1-1 contra AFC Wimbledon el 2027-11-17

Plantilla: 38 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
