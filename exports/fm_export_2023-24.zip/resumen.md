# Dartford 2023/24 (FM24, mánager Adrián Varela)

- **Liga:** Vanarama National League South, 1.º de 24 con 116 puntos (37V 5E 4D, 133-63).
- **Oficiales:** 56 partidos, 44V 6E 6D, goles 162-77.
- Copa FA inglesa: 6 partidos, 4V 1E 1D.
- Trofeo FA inglés: 4 partidos, 3V 0E 1D.

- **Goleadores:** Manny Adebowale 23, Fumnaya Shomotun 21, Luke Coulson 21.
- **Asistencias:** Fumnaya Shomotun 18, Sam Odaudu 17, Alfie Matthews 15.
- **Mejor nota (mín. 10 partidos):** Alfie Matthews 7.31, Sam Odaudu 7.26, Alex Wall 7.24.
- **Más partidos:** Fumnaya Shomotun 55, Manny Adebowale 53, Billy Terrell 52.
- **Mayor victoria:** 6-0 a Weymouth (2024-01-27). **Peor derrota:** 1-4 contra Truro City (2024-04-20).
- **Rachas:** 11 victorias seguidas, 15 sin perder; 18 porterías a cero.
- **Público en casa:** media de 1.246 espectadores.
- **Traspasos:** 5 fichajes (12.399 €) y 4 salidas (0 €).
- **Economía (suma mensual):** ingresos 8.598.449 €. gastos 6.230.146 €. neto 2.368.302 €.

**Hitos:**
- 1.º de 24 en Vanarama National League South con 116 puntos
- 3 goles de Luke Coulson en un partido contra Weston-super-Mare el 2023-10-17
- 3 goles de Manny Adebowale en un partido contra Bath City el 2024-01-13
- 3 goles de Charlie Sheringham en un partido contra Eastbourne Borough el 2024-04-01
- Copa FA inglesa: 6 partidos; el último, no ganado 3-5 contra AFC Fylde el 2023-12-02
- Trofeo FA inglés: 4 partidos; el último, no ganado 0-3 contra Darlington el 2024-02-10

Plantilla: 44 jugadores. Datos completos en los JSON de este zip (`README.md` explica cada campo).
